const createSpaServer = require('spaserver').createSpaServer;
const http = require('http');
const dateFormat = require('dateformat');
const fs = require('fs');
const url = require('url');
const uniqid = require("uniqid");
const Entities = require('html-entities').AllHtmlEntities;
const entities = new Entities();
const crypto = require("crypto");

let ucty = new Array();
if (fs.existsSync("ucty.json")){
    ucty = JSON.parse(fs.readFileSync("ucty.json"))
}
let citac = 0;
let msgs = new Array();
let PORT = 8080
function hesovaciFunkce(pw){
    let mixPw = crypto.createHash("md5").update(pw).digest("hex");
    return mixPw;
}
function zalozUcet (FucetName, Fheslo) {
    nicknameExits = false;
    let ucet = {};
    ucet.nickname = FucetName;
    ucet.password = hesovaciFunkce(Fheslo);
    for (let u of ucty){
        if (u.nickname === ucet.nickname){
            nicknameExits = true;
            break
        }
    }
    if (nicknameExits == false){
        ucty.push(ucet)}
}
function processApi(req, res){console.log(req.url);
    if (req.pathname == "/jinastranka") {
        res.writeHead(200, {"Content-type": "text/html"});
        res.end("<html lang='cs'><head><meta charset='UTF8'></head><req.parameters>blablabla</req.parameters></html>");
    } else if (req.pathname == "/jsondemo") {
        res.writeHead(200, {"Content-type": "application/json"});
        let obj = {};
        obj.jmeno = "Bob";
        obj.prijmeni = "Bobíček";
        obj.rokNarozeni = 2002;
        res.end(JSON.stringify(obj));
    } else if (req.pathname == "/jsoncitac") {
        res.writeHead(200, {"Content-type": "application/json"});
        let obj = {};
        obj.pocetVolani = citac;
        res.end(JSON.stringify(obj));
    } else if (req.pathname == "/denvtydnu") {
        res.writeHead(200, {
            "Content-type": "application/json",
        });
        let d = new Date();
        let obj = {};
        obj.systDatum = d;
        obj.denVTydnuCiselne = d.getDay(); //0...nedele, 1...pondeli,...
        obj.datumCesky = d.getDate() + "." + (d.getMonth()+1) + "." + d.getFullYear(); //leden...0, unor...1,...
        obj.datumCeskyFormat = dateFormat(d, "dd.mm.yyyy");
        obj.datumACasCeskyFormat = dateFormat(d, "dd.mm.yyyy HH:MM:ss");
        obj.casCesky = d.getHours() + "." + d.getMinutes() + "." + d.getSeconds();
        obj.denVTydnuCesky = DNY_V_TYDNU[d.getDay()];
        res.end(JSON.stringify(obj));
    } else if (req.pathname == "/svatky") {
        res.writeHead(200, {
            "Content-type": "application/json"
        });
        let obj = {};
        if (req.parameters["m"] && req.parameters["d"] ) {
            let d = req.parameters["d"];
            let m = req.parameters["m"];
            obj.datum = d+"."+m+".";
            obj.svatek = SVATKY[m][d];
        } else {
            let d = new Date();
            obj.datum = dateFormat(d, "dd.mm.yyyy");
            obj.svatek = SVATKY[d.getMonth()+1][d.getDate()];
            d.setDate(d.getDate() + 1);
            obj.svatekZitra = SVATKY[d.getMonth()+1][d.getDate()];
        }
        res.end(JSON.stringify(obj));
    } else if (req.pathname == "/chat/listmsgs") { //msgs...globalni promenna typu pole deklarovana na zacatku tohoto zdroje
        res.writeHead(200, {"Content-type": "application/json"});
        let obj = {};
        obj.messages = msgs;
        res.end(JSON.stringify(obj));
    } else if (req.pathname == "/ucet/showall"){
        res.writeHead(200, {"Content-type": "application/json"});
        let obj = {};
        obj.showAllAcounts = ucty;
        res.end(JSON.stringify(obj));
    } else if (req.pathname == "/chat/addmsg") {
        res.writeHead(200, {
            "Content-type": "application/json"
        });
        let obj = {};
        obj.text = req.parameters.msg;
        obj.time = new Date();
        msgs.push(obj);
        res.end(JSON.stringify(obj));
            }
        else if (req.pathname == "/ucet/zaloz") {
        res.writeHead(200, {"Content-type": "application/json"});
        let obj = {};
        let ucetName;
        ucetName = req.parameters.nickname;
        let heslo;
        heslo = req.parameters.password;

        zalozUcet (ucetName, heslo);
        fs.writeFileSync("ucty.json", JSON.stringify(ucty, null, 2));

        res.end(JSON.stringify(obj));
    }else if (req.pathname == "/ucet/zahesuj"){
        res.writeHead(200, {"Content-type": "application/json"});
                let obj = {};
                obj.passwordzpet = hesovaciFunkce(req.parameters.password);
                console.log("lol");
                console.log(req.parameters.password);
                res.end(JSON.stringify(obj));
            }
        else if (req.pathname == "/nahodnecislo") {
        res.writeHead(200, {"Content-type": "application/json"});
        let cislom = Math.floor(Math.random() * 10)
        res.end(JSON.stringify(cislom));
    } else {
        res.writeHead(200, {"Content-type": "text/html"});
        res.end("<html lang='cs'><head><meta charset='UTF8'></head><req.parameters>Počet volání: " +citac + "</req.parameters></html>");
    }

}
createSpaServer(PORT, processApi)
